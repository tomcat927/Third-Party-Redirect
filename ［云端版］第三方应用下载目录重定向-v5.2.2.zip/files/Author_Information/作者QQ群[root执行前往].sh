#!/system/bin/sh
/data/adb/modules/Third_Party_Redirect/files/Author_Information/QQGroup